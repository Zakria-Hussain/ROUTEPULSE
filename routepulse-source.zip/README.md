# RoutePulse — Smart Public Transport & Bus Tracking

A Vercel-ready Next.js platform for passengers, drivers, and transport operators. The core flow is real: search a route, watch a moving bus, calculate ETA, send driver locations, complete trips, and review analytics.

## Features
- Passenger route search with direct-route and transfer suggestions.
- OpenStreetMap/Leaflet live map with moving bus markers, ETA, stop sequence, simulated badge, and stale-location handling.
- Driver mobile workflow with browser-side simulated GPS posting to the same location endpoint every 2 seconds.
- Operator monitor, service alert publishing, trip metrics, peak-hour charts, and performance insight.
- JWT httpOnly cookie authentication and role-aware workspaces.

## Accounts
Create a real passenger account from the public registration page. Driver, operator, and administrator access is assigned by the transit team.

## Local setup
1. Create a Neon Postgres database and copy its connection string.
2. `cp .env.example .env.local`; set `DATABASE_URL` and `JWT_SECRET`.
3. `npm install && npm run db:setup && npm run dev`
4. Open http://localhost:3000.

## Product walkthrough
1. Create a passenger account and search Central Station → University Gate.
2. Follow Route 05 on the live map and inspect stop-by-stop arrivals.
3. Authorized drivers can share GPS and flag a delay or crowd event.
4. Authorized operators can review the live monitor, charts, and service alerts.

## How simulation works
The simulator runs in the browser, interpolates ten points between each ordered stop, and POSTs each point to `/api/trips/[id]/location`. The driver/operator tab must remain open. Real phone GPS can use the same endpoint contract with `navigator.geolocation.watchPosition`.

## Known limitations
This intentionally uses 2-second HTTP polling instead of WebSockets. Driver simulation remains available as an operational fallback when a real GPS signal is unavailable.
