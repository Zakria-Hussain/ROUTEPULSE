import { query } from '@/lib/db';
import { hashPassword,signToken,setAuthCookie } from '@/lib/auth';
import { NextResponse } from 'next/server';
export const dynamic='force-dynamic';

export async function POST(req){
  try {
    const {name,email,password,role='passenger'}=await req.json();
    const allowed=['passenger','driver','operator'];
    if(!name?.trim()||!email?.trim()||!password||password.length<6||!allowed.includes(role)) return NextResponse.json({error:'Name, email, password (6+ characters), and a valid account type are required'},{status:400});
    const rows=await query('INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING user_id,name,email,role',[name.trim(),email.trim().toLowerCase(),await hashPassword(password),role]);
    const user=rows[0];
    if(role==='driver') await query("INSERT INTO drivers(user_id,name,status) VALUES($1,$2,'Available')",[user.user_id,user.name]);
    return setAuthCookie(NextResponse.json({user},{status:201}),await signToken(user));
  } catch(e) {
    return NextResponse.json({error:e.code==='23505'?'Email already registered':e.message},{status:e.code==='23505'?409:500});
  }
}
