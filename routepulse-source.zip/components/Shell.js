'use client';
import {useRouter} from 'next/navigation';
import ThemeToggle from './ThemeToggle';

export default function Shell({user,children,title,eyebrow}){
  const router=useRouter();
  return <div className="min-h-screen grain">
    <header className="nav nav-grid px-5 lg:px-8 py-4">
      <div className="max-w-7xl mx-auto w-full flex justify-between items-center gap-4">
        <button onClick={()=>router.push('/')} className="flex items-center gap-3 shrink-0" aria-label="Go to RoutePulse home"><span className="w-9 h-9 rounded-xl bg-[#7ee0c3] text-[#10201f] grid place-items-center font-black">↗</span><span className="font-black tracking-tight text-xl">Route<span className="text-[#7ee0c3]">Pulse</span></span></button>
        <div className="flex items-center gap-3"><div className="hidden lg:flex items-center gap-2 text-xs text-[#b8d3c9]"><span className="dot pulse"/> Network online · polling live</div><span className="badge bg-[#244440] text-[#d8f7ed]">{user?.role}</span><ThemeToggle/><button className="text-sm text-[#b8d3c9] hover:text-white" onClick={async()=>{await fetch('/api/auth/logout',{method:'POST'});router.push('/login')}}>Sign out</button></div>
      </div>
    </header>
    <main className="max-w-7xl mx-auto px-4 lg:px-8 py-8 lg:py-12"><div className="mb-8 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4"><div><div className="eyebrow">{eyebrow}</div><h1 className="display text-4xl lg:text-6xl mt-2">{title}</h1></div><div className="text-right hidden lg:block"><div className="muted text-xs uppercase tracking-[.18em]">Lahore network</div><div className="font-bold text-sm mt-1">Live operations</div></div></div>{children}</main>
  </div>;
}
