'use client';
import {useEffect,useState} from 'react';

export default function ThemeToggle(){
  const [dark,setDark]=useState(false);
  useEffect(()=>{
    const stored=localStorage.getItem('routepulse-theme');
    const next=stored==='dark' || (!stored && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.classList.toggle('dark',next);
    setDark(next);
  },[]);
  function toggle(){
    const next=!dark;
    document.documentElement.classList.toggle('dark',next);
    localStorage.setItem('routepulse-theme',next?'dark':'light');
    setDark(next);
  }
  return <button type="button" onClick={toggle} className="theme-toggle" aria-label={dark?'Switch to light mode':'Switch to dark mode'} title={dark?'Light mode':'Dark mode'}><span aria-hidden="true">{dark?'☼':'◐'}</span><span className="hidden sm:inline">{dark?'Light':'Dark'}</span></button>;
}
