'use client';
import Link from 'next/link';
import ThemeToggle from './ThemeToggle';

export default function PublicHeader({active}){
  return <header className="public-header"><div className="max-w-7xl mx-auto px-5 lg:px-10 h-[76px] flex items-center justify-between gap-5"><Link href="/" className="brand-lockup" aria-label="RoutePulse home"><span className="brand-mark">↗</span><span className="brand-name">Route<span>Pulse</span></span></Link><nav className="hidden md:flex items-center gap-7 text-sm font-semibold text-[#b8d3c9]" aria-label="Primary navigation"><a href="#product" className={active==='product'?'nav-link active':'nav-link'}>Product</a><a href="#how-it-works" className={active==='how'?'nav-link active':'nav-link'}>How it works</a><a href="#teams" className={active==='teams'?'nav-link active':'nav-link'}>For teams</a></nav><div className="flex items-center gap-2"><ThemeToggle/><Link href="/login" className="header-link hidden sm:inline-flex">Sign in</Link><Link href="/register" className="btn btn-light text-sm py-2.5 px-4">Create account <span>→</span></Link></div></div></header>;
}
